'''Dummy module'''

def function():
    '''Do nothing'''
